#ifndef FCSR_H
#define FCSR_H

//On découpe d = AE985DFF 26619FC5 8623DC8A AF46D590 3DD4254E
//En 5 parties de 4 octets (rester en seule partie poserait problème en mémoire)
#define d0 0x3DD4254E    /* bits de poids faible */ 
#define d1 0xAF46D590
#define d2 0x8623DC8A
#define d3 0x26619FC5    
#define d4 0xAE985DFF    /* bits de poids forts */

#define NB_BITS 31

//On considère qu'on travaille sur des tableaux de 5 entiers de 32 bits (5*32 = 160) soit la taille du registre 
//D'un FCSR-H
typedef struct fcsr
{
	unsigned* main_reg; //Registre principal
	unsigned* carry_reg; //Registre des retenues
	unsigned* filter; //Filtre sur le FCSR-H
}FCSR;

void alloc_fcsr(FCSR* fcsr);
void free_fcsr(FCSR* fcsr);
void init_fcsr(FCSR* fcsr, unsigned* key, unsigned* init_vect);
void do_iteration(FCSR* fcsr);
unsigned produce_filtered_byte(FCSR *fcsr);
void compute_init(FCSR* fcsr);
void encrypt_decrypt_algo(FCSR* fcsr, unsigned* text,unsigned *result,int text_len);

#endif