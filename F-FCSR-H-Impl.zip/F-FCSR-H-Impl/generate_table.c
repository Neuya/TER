#define GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>

#include "table.h"
#include "utils.h"


int*** generatePiMatrixes()
{
	int*** P = (int***)malloc(8*sizeof(int**));
	int** F = malloc(8*sizeof(int*));
	for(int i=0;i<8;i++)
	{
		P[i] = (int**)malloc(20*sizeof(int*));
		F[i]=malloc(sizeof(int)*20);
	
		for(int j=0;j<20;j++)
		{
			//printf("I / J : %d / %d \n",i,j);
			P[i][j]=(int*)malloc(20*sizeof(int));
		}
	}  
	F[0] = bin_to_array(226474); //00110111010010101010
	F[1] = bin_to_array(634305); //10011010110111000001
	F[2] = bin_to_array(768751); //10111011101011101111
	F[3] = bin_to_array(992137); //11110010001110001001
	F[4] = bin_to_array(467516); //01110010001000111100
	F[5] = bin_to_array(640138); //10011100010010001010
	F[6] = bin_to_array(217701); //00110101001001100101
	F[7] = bin_to_array(867252); //11010011101110110100

	int shift=0;
	int k=0;
	for(int i=0;i<8;i++)
	{
		k = i;
		for(int j=0;j<20;j++)
		{
			shift = (j+k) / 8;
			rotate_left(P[i][j],F[k],shift);
			k = mod(k-1,8);
		}
	}

	return P;
}

//Generation du fichier tablei
void generate_dump_table(TABLE table,int i)
{
	FILE *table_dump;
	char c[15];
	sprintf(c,"./dumps/table%d",i);

	table_dump = fopen(c,"w");
	for(int i=0;i<TABLE_SIZE;i++)
	{
		//fprintf(table_dump,"%d\n",i);
		fprintf(table_dump,"%d\n",table[i].sol_number);
		for(int j=0;j<table[i].sol_number;j++)
			fprintf(table_dump,"%d\n",table[i].solutions[j]);
		fprintf(table_dump,"$\n");
	}
}

//Charger une table depuis le fichier Tablei
void load_table(int i)
{
	TABLE table = malloc(sizeof(struct TABLE_SOL)*TABLE_SIZE);
	FILE *table_dump;
	char c[7];
	sprintf(c,"table%d",i);
	char *line = NULL;
	//size_t characters = 0;
	size_t len = 0;
	table_dump = fopen(c,"r");
	for(int i=0;i<TABLE_SIZE;i++)
	{
		getline(&line,&len,table_dump);
		sscanf(line,"%d",&table[i].sol_number);
		table[i].solutions = malloc(sizeof(int)*table[i].sol_number);
		for(int j=0;j<table[i].sol_number;j++)
		{
			getline(&line,&len,table_dump);
			sscanf(line,"%d",&table[i].solutions[j]);
		}
	}
}

int main()
{
	int*** PMatrixes = generatePiMatrixes();
	for(int i=0;i<8;i++)
	{
		print_matrix(PMatrixes[i]);
	}
	TABLE table = malloc(sizeof(struct TABLE_SOL)*TABLE_SIZE);
	for(int i=0;i<TABLE_SIZE;i++)
	{
		table[i].sol_number = 2;
		table[i].solutions = malloc(sizeof(int)*table[i].sol_number);
		for(int j=0;j<2;j++)
		{
			table[i].solutions[j] = 1;
		}
	}
	generate_dump_table(table,0);
	return 1;
}