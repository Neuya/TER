#ifndef TABLE_H
#define TABLE_H 

#define TABLE_SIZE 1048576 // 2^20

struct TABLE_SOL
{
	int sol_number;
	int* solutions;
};

#define TABLE struct TABLE_SOL*

#endif