#include "utils.h"

//Voir utils.h pour les commentaires sur les fonctions

int* bin_to_array(int number)
{
	int* F = malloc(sizeof(int)*20);
	for(int i=0;i<20;i++)
	{
		F[19-i] = number & 1;
		number = number >> 1;
	}
	return F;
}

int powa(int a,int b)
{
	return b==0?1:a*powa(a,b-1);
}

int bin_array_to_int(int *tab)
{
	int r = 0;
	for(int i=0;i<20;i++)
	{
		r+= powa(2,19-i)*tab[i];
	}
	return r;
}

void print_array(int* tab)
{
	printf("[");
	for(int i=0;i<20;i++)
	{
		printf("%d",tab[i]);
	}
	printf("]\n");
}

void print_matrix(int** mat)
{
	printf("Mat : \n{\n");
	for(int i=0;i<20;i++)
	{
		print_array(mat[i]);
	}	
	printf("}\n"); 
}


void rotate_left(int* P,int* F,int shift)
{
	for(int i=0;i<20;i++)
	{
		P[i] = F[(i+shift)%20];
	}
}

int mod(int a,int b)
{
	return (a%b+b) % b;
}
