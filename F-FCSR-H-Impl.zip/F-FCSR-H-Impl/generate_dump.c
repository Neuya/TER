#include <stdio.h>
#include <stdlib.h>
#include "fcsr.h"

#define MAX_DUMP_SIZE 67108864 //2^26


int main()
{
	unsigned KEY[10] = { 0x00, 0x88 , 0x63 , 0x9d, 0x6b , 0xf8 , 0x47 , 0xed , 0x59 , 0xc6 };
	unsigned IV[10]= { 0x00 , 0x11 , 0x22 , 0x33 , 0x44 , 0x55 , 0x66 , 0x77 , 0x88 , 0x99 };

	FCSR *fcsr = malloc(sizeof(struct fcsr));
	alloc_fcsr(fcsr);
	
	init_fcsr(fcsr,KEY,IV);
	compute_init(fcsr);

	FILE *dump;

	dump = fopen("./dumps/fcsr-dump","w");

	char tmp;
	for(int i=0;i<MAX_DUMP_SIZE;i++)
	{
		do_iteration(fcsr);
		tmp = produce_filtered_byte(fcsr);
		fprintf(dump, "%c", tmp);
	}

	fclose(dump);

	return EXIT_SUCCESS;
}