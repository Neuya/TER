#include <stdio.h>
#include <stdlib.h>
#include "fcsr.h"

void alloc_fcsr(FCSR* fcsr)
{
	//On suppose que le fcsr a été alloué en mémoire
	//On va maitenant allouer les différents tableaux
	fcsr->main_reg = malloc(sizeof(unsigned)*5);
	fcsr->carry_reg = malloc(sizeof(unsigned)*5);
	fcsr->filter = malloc(sizeof(unsigned)*5);
}

void free_fcsr(FCSR* fcsr)
{
	free(fcsr->main_reg);
	free(fcsr->carry_reg);
	free(fcsr->filter);
	free(fcsr);
}

void init_fcsr(FCSR* fcsr, unsigned* key, unsigned* init_vect)
{ 
	//On remplit le tableau du filtre (ie : des filtres)
	//On le remplit avec les bits de poids faible en premier
	//Mit bout à bout cela donne :
	// Filter = 3DD4254E AF46D590 8623DC8A 26619FC5 AE985DFF
	fcsr->filter[0] = d0; 
	fcsr->filter[1] = d1;
	fcsr->filter[2] = d2;
	fcsr->filter[3] = d3;
	fcsr->filter[4] = d4;

	//On va maintenant insérer la clé dans les 80 premiers bits 
	//du registre principal

	//Premiers 32 bits du registre :
	//On fait | ( <=> ou) et key[x] << n pour mettre n zéros derrière la valeur 
	/*printf("Key[9] : %x Key[8] : %x ",key[9] & 0xff,key[8]<<8);
	printf("Key[6] : %x ",key[6]<<24);
	printf("Key[6] | key[9] :%x",key[9] << 24 | key[6] << 24);*/
	fcsr->main_reg[0] = key[9] | key[8] << 8 | key[7] << 16 | key[6] << 24;
	fcsr->main_reg[1] = key[5] | key[4] << 8 | key[3] << 16 | key[2] << 24;
	fcsr->main_reg[2] = key[1] | key[0] << 8 | init_vect[9] << 16 | init_vect[8] << 24; // 80 bits remplis on continue par le vecteur initial
	fcsr->main_reg[3] = init_vect[7] | init_vect[6] << 8 | init_vect[5] << 16 | init_vect[4] << 24;
	fcsr->main_reg[4] = init_vect[3] | init_vect[2] << 8 | init_vect[1] << 16 | init_vect[0] << 24; // 160 bits remplis

	//On va maintenant initialiser le registre des retenues à zéro : 
	fcsr->carry_reg[0] = 0;
	fcsr->carry_reg[1] = 0;
	fcsr->carry_reg[2] = 0;
	fcsr->carry_reg[3] = 0;
	fcsr->carry_reg[4] = 0; 

	//Notre FCSR a maintenant ses données d'initialisations insérées. 
}



void do_iteration(FCSR* fcsr)
{
	int last_bit; 
	unsigned int_reg[5]; //registre intermédiaire utile aux calculs

	last_bit = (int)(fcsr->main_reg[0] << NB_BITS) >> NB_BITS; //On récupère le dernier bit du registre
	//printf("last_bit : %d\n",last_bit);
	//On décale le registre pour les calculs à suivre:

	//On décale le nombre d'un bit vers la droite
	fcsr->main_reg[0] = fcsr->main_reg[0] >> 1; //(<=> >>=)
	//On récupère le dernier bit (a_32)
	fcsr->main_reg[0] |= (fcsr->main_reg[1] & 1) << NB_BITS;

	//On effectue ces opérations sur les autres parties du tableau

	fcsr->main_reg[1] >>= 1;
	fcsr->main_reg[1] |= (fcsr->main_reg[2] & 1) << NB_BITS;

	fcsr->main_reg[2] >>= 1;
	fcsr->main_reg[2] |= (fcsr->main_reg[3] & 1) << NB_BITS;

	fcsr->main_reg[3] >>= 1;
	fcsr->main_reg[3] |= (fcsr->main_reg[4] & 1) << NB_BITS;

	//Sauf pour le dernier indice du tableau, que l'on va simplement décaler d'un bit
	// car a_159 sera calculé ultérieurement
	fcsr->main_reg[4] >>= 1;
	//On a bien décalé notre registre vers la droite

	//On va maintenant calculer les nouvelles valeurs des différents registres
	//Rappel : 
	//A_i(t+1) = A_i(t)div2 XOR C_i(t) XOR A_0(t)*D
	//C_i(t+1) = A_i(t)div2 & C_i(t) XOR C_i(t) & A_0(t)*D XOR A_0(t)*D & A_i(t)div2

	//Opérateur ^ => XOR
	//A(t+1) = (A(t)div 2) XOR C(t)
	//Remarque : on ne fait pas tout le calcul car ce résultat intermédiaire est utilisé plus loin
	//Cela fait gagner du temps de calcul
	int_reg[0] = fcsr->main_reg[0] ^ fcsr->carry_reg[0];
	int_reg[1] = fcsr->main_reg[1] ^ fcsr->carry_reg[1];
	int_reg[2] = fcsr->main_reg[2] ^ fcsr->carry_reg[2];
	int_reg[3] = fcsr->main_reg[3] ^ fcsr->carry_reg[3];
	int_reg[4] = fcsr->main_reg[4] ^ fcsr->carry_reg[4];

	//Intermédiaire:
	//C(t+1) = (A(t)div2) & C(t)
	fcsr->carry_reg[0] &= fcsr->main_reg[0];
	fcsr->carry_reg[1] &= fcsr->main_reg[1];
	fcsr->carry_reg[2] &= fcsr->main_reg[2];
	fcsr->carry_reg[3] &= fcsr->main_reg[3];
	fcsr->carry_reg[4] &= fcsr->main_reg[4];

	//On sépare le calcul pour plus de clarté
	//C(t+1) = C(t+1) XOR (A(t)div2) XOR C(t) XOR A_0(t)&D
	fcsr->carry_reg[0] ^= int_reg[0] & (last_bit & fcsr->filter[0]);//filter[n] <=> dn
	fcsr->carry_reg[2] ^= int_reg[2] & (last_bit & fcsr->filter[2]); 
	fcsr->carry_reg[1] ^= int_reg[1] & (last_bit & fcsr->filter[1]); 
	fcsr->carry_reg[3] ^= int_reg[3] & (last_bit & fcsr->filter[3]); 
	fcsr->carry_reg[4] ^= int_reg[4] & (last_bit & fcsr->filter[4]); 

	//On fait maintenant le dernier XOR sur le nouveau registre principal:
	int_reg[0] ^= (last_bit & fcsr->filter[0]);
	int_reg[1] ^= (last_bit & fcsr->filter[1]);
	int_reg[2] ^= (last_bit & fcsr->filter[2]);
	int_reg[3] ^= (last_bit & fcsr->filter[3]);
	int_reg[4] ^= (last_bit & fcsr->filter[4]);

	//On remplace désormais le registre : 
	fcsr->main_reg[0] = int_reg[0];
	fcsr->main_reg[1] = int_reg[1];
	fcsr->main_reg[2] = int_reg[2];
	fcsr->main_reg[3] = int_reg[3];
	fcsr->main_reg[4] = int_reg[4];

	//On a effectué une itération sur notre FCSR
}

//Fonction de production d'un octet en fonction du registre principal du FCSR
unsigned produce_filtered_byte(FCSR *fcsr)
{
	unsigned int_reg[5];

	int_reg[0] = fcsr->filter[0] & fcsr->main_reg[0];
	int_reg[1] = fcsr->filter[1] & fcsr->main_reg[1];
	int_reg[2] = fcsr->filter[2] & fcsr->main_reg[2];
	int_reg[3] = fcsr->filter[3] & fcsr->main_reg[3];
	int_reg[4] = fcsr->filter[4] & fcsr->main_reg[4];

	//int_reg[0] = filter[0] & state[0] XOR filter[1] & state[1]
	int_reg[0] ^= int_reg[1];
	int_reg[2] ^= int_reg[3];
	
	//int_reg[0] = int_reg[0] XOR (filter[2] and state[2] XOR filter[3] and state[3])
	int_reg[0] ^= int_reg[2]^ int_reg[4];
	

	int_reg[0] ^= ( int_reg[0] >> 16 );
	int_reg[0] ^= ( int_reg[0] >> 8  );

	return int_reg[0] & 0xff;
}

void compute_init(FCSR* fcsr)
{
	//On va effectuer les manoeuvres d'initialisation d'un FCSR
	//Produire 20 octets (filtrés)
	//Remplacer le registre principal par ces 20 octets
	//Puis faire tourner le FCSR 162 fois

	unsigned Temp[20];

	//On produit 20 octets
	for(int i=0;i<20;i++)
	{
		do_iteration(fcsr);
		Temp[i] = produce_filtered_byte(fcsr);
		//printf("S[%d] = %x \n",i,Temp[i]);
	}

	//On remplace le registre principal
	fcsr->main_reg[0] = Temp[3]  << 24  | Temp[2] << 16  | Temp[1] << 8  | Temp[0];
	fcsr->main_reg[1] = Temp[7]  << 24  | Temp[6] << 16  | Temp[5] << 8  | Temp[4];
	fcsr->main_reg[2] = Temp[11] << 24  | Temp[10] << 16 | Temp[9] << 8  | Temp[8];
	fcsr->main_reg[3] = Temp[15] << 24  | Temp[14] << 16 | Temp[13] << 8 | Temp[12];
	fcsr->main_reg[4] = Temp[19] << 24  | Temp[18] << 16 | Temp[17] << 8 | Temp[16];

	//On remet le registre des retenues à zéro
	fcsr->carry_reg[0] = 0;
	fcsr->carry_reg[1] = 0;
	fcsr->carry_reg[2] = 0;
	fcsr->carry_reg[3] = 0;
	fcsr->carry_reg[4] = 0; 

	//On effectue 162 itérations
	for(int i=0;i<162;i++)
	{
		do_iteration(fcsr);
	}
		
}

void encrypt_decrypt_algo(FCSR* fcsr, unsigned* text,unsigned *result,int text_len)
{	
			
	for(int i=0;i<text_len;i++)
	{
		do_iteration(fcsr);
		result[i] = text[i] ^ produce_filtered_byte(fcsr);
	}
	
}
