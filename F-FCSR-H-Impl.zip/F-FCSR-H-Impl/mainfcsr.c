#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fcsr.h"


int main()
{
	//constantes
	unsigned testKEY[10] = { 0x00, 0x88 , 0x63 , 0x9d, 0x6b , 0xf8 , 0x47 , 0xed , 0x59 , 0xc6 };
	unsigned testIV[10]= { 0x00 , 0x11 , 0x22 , 0x33 , 0x44 , 0x55 , 0x66 , 0x77 , 0x88 , 0x99 };
	//unsigned text[10]={'S','O','S','E','M','A','N','U','K','S'};
	unsigned text2[10]={'B','U','O','N','G','I','O','R','N','O'};
	unsigned encrypted[9];
	unsigned decrypted[9];
	
	//Allocation de mémoire
	FCSR *fcsr = malloc(sizeof(struct fcsr));
	alloc_fcsr(fcsr);

	printf("Texte exemple : ");
	for(int i=0;i<10;i++)
	{
		printf("%c",text2[i]);
	}
	
	//Initialisation du FCSR
	init_fcsr(fcsr,testKEY,testIV);
	compute_init(fcsr);
	encrypt_decrypt_algo(fcsr,text2,encrypted,10);
	

	printf("\nEncrypted : ");
	for(int i=0;i<10;i++)
	{
		printf("%x",encrypted[i]);
	}

	init_fcsr(fcsr,testKEY,testIV);
	compute_init(fcsr);
	encrypt_decrypt_algo(fcsr,encrypted,decrypted,10);
	
	printf("\nDecrypted : ");
	for(int i=0;i<10;i++)
	{
		printf("%c",decrypted[i]);
	}


	size_t lens = 0;
  	ssize_t lineSize = 0;
  	char* line;
  	
  	do
	{
		printf("\n\nEntrez un mot ou une phrase afin de la passer dans l'automate :");
		printf("\nquit pour quitter\n");
		lineSize = getline(&line, &lens, stdin);
		
		if(strcmp(line,"quit")!=10){
			int len = lineSize-1;
			printf("Vous avez entré : %s\n",line);
			unsigned encrypted2[len];
			unsigned decrypted2[len];
			unsigned text[len];
			for(int i=0;i<len;i++)
			{
				text[i] = line[i];
			}

			init_fcsr(fcsr,testKEY,testIV);
			compute_init(fcsr);
			encrypt_decrypt_algo(fcsr,text,encrypted2,len);
			
			printf("\nEncrypted : ");
			for(int i=0;i<len;i++)
			{
				printf("%x",encrypted2[i]);
			}
	
			init_fcsr(fcsr,testKEY,testIV);
			compute_init(fcsr);
			encrypt_decrypt_algo(fcsr,encrypted2,decrypted2,len);

			printf("\nDecrypted : ");
			for(int i=0;i<len;i++)
			{
				printf("%c",decrypted2[i]);
			}
		}

	}while (strcmp(line,"quit")!=10);

	free(line);
	free_fcsr(fcsr);

	return EXIT_SUCCESS;
}