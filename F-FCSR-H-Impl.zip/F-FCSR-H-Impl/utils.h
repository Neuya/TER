#ifndef UTILS_H
#define UTILS_H
#include <stdio.h>
#include <stdlib.h>

/*
Fonction transformant un entier en un tableau 
contenant la valeur binaire (taille 20) de ce nombre dans l'ordre
@Return : int* (size : 20)
*/
int* bin_to_array(int number);

/*
Fonction puissance a^b
*/
int powa(int a,int b);

/*
Fonction inverse de bin_to_array, étant donné un tableau de bits
renvoie la valeur en base 10 de ce tableau
@Return : int la valeur en base 10 des bits de *tab
*/
int bin_array_to_int(int *tab);

/*
Fonction d'affichage d'un tableau
*/
void print_array(int* tab);

/*
Fonction d'affichage d'une matrice
*/
void print_matrix(int** mat);

/*
Fonction de rotation d'un tableau
Ecrit dans P la valeur de F décalé de "shift" vers la gauche
*/
void rotate_left(int* P,int* F,int shift);

/*
Fonction modulo plus abouti que la librairie standard : 
Prend en compte les modulos négatifs !
@return a mod b
*/
int mod(int a,int b);

#endif