#Implémentation F-FCSR-H et son attaque

##Compilation

Il vous suffit de vous placer dans le dossier et de faire make

##Différents exécutables 

Ce projet comprend plusieurs exécutables : 
- fcsr : l'implémentation du fcsr
- generate_dump : Va générer un dump contenant les octets de sortie du FCSR
(filtrés)
- generate_table : Génère les tables de précalcul (fonctionnel mais inutile)

##Implémentation du FCSR

Il vous suffit de vous placer dans le dossier et de lancer l'exécutable ./fcsr
Vous verrez quelques exemples déjà écrits, et vous serez amenés à rentrer des mots et phrases afin de tester le bon fonctionnement de l'automate

##Génération des octets du fcsr

Grâce à l'exécutable ./generate_dump vous pourrez produire 2^26 octets et les stocker dans un fichier ./dumps/fcsr-dump

##Exécuter l'attaque

Afin d'exécuter l'attaque sur un FCSR-H il vous faudra au préalable générer les tables et les sauvegarder dans un fichier, pour cela il vous faudra vous prémunir de sage et de rentrer : 

```
attach("./generate_tables.sage")
generate_tables_and_dump()
```

Attention le temps d'exécution peut être particulièrement long

